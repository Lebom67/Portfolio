/*------------------------------------------------------------------
[Master Scripts]

Project:    Siber Theme
Version:    1.0.2

[Table of contents]

[Components]

	-Preloader
	-Stick sidebar
	-Dropdown img
	-Equal Height function
	-Navigation open
	-Search
	-Mobile menu
	-Fixed header
	-Screen rezise events
	-Fix centered container
	-Blog items & filtering
	-Full sreen navigation
	-Animation
	-Animation
	-Load more
	-Comment reply
	-Popup image
	-Parallax
	-Tabs
	-Quantity
	
-------------------------------------------------------------------*/

"use strict";

/*------------------------------------------------------------------
[ Preloader ]
*/
jQuery(window).on('load', function () {
    jQuery(window).trigger('resize').trigger('scroll');
    jQuery('body').addClass('loaded');

    jQuery('.owl-carousel').each(function(){
		jQuery(this).trigger('refresh.owl.carousel');
	});
});

jQuery('.tabs').each(function(){
	var item = jQuery(this).find('.item'),
		tabs_head = jQuery(this).find('.tabs-head');
	item.each(function() {
		var name = jQuery(this).data('name');
		tabs_head.append('<div class="item"><div class="cell">'+name+'</div></div>');
	});
	tabs_head.find('.item:first-of-type').addClass('active-tab');
	jQuery(this).find('.tabs-body .item:first-of-type').css('display', 'block');

	jQuery('.tabs-head').on('click', '.item:not(.active-tab)', function() {  
		jQuery(this).addClass('active-tab').siblings().removeClass('active-tab').parents('.tabs').find('.tabs-body .item').eq(jQuery(this).index()).fadeIn(150).siblings().hide();  
	});
});

function leadZero(n) { return (n < 10 ? '0' : '') + n; }

/*------------------------------------------------------------------
[ Equal Height function ]
*/
function equalHeight(group) {
    if(jQuery(window).width() > '769') {
		var tallest = 0;
       	jQuery(group).each(function() {
            var thisHeight = jQuery(this).css('height', '').outerHeight();
            if(thisHeight > tallest) {
                tallest = thisHeight;
            }
        });
        jQuery(group).css('height', tallest);
    } else {
    	jQuery(group).css('height', '');
    }
}

jQuery(document).ready(function() {

    if(jQuery('.navigation > ul > li').length > 6) {
		jQuery('.navigation').addClass('min');
	}

	jQuery('#wpadminbar').addClass('wpadminbar');

	/*------------------------------------------------------------------
	[ Project slider ]
	*/
	jQuery('.project-slider').each(function(){
		var head_slider = jQuery(this);
		if(jQuery(this).find('.item').length > 1){
			head_slider.addClass('owl-carousel').owlCarousel({
				loop:true,
				items:1,
				nav: true,
				dots: false,
				autoplay: false,
				autoHeight: true,
				navClass: ['owl-prev base-icons-prev','owl-next base-icons-next'],
				navText: false,
				responsive:{
					0:{
						nav: false,
					},
					480:{

					},
					769:{
						nav: true,
					},
				},
			});
		}
	});


    /*------------------------------------------------------------------
	[ Search ]
	*/

	jQuery('.site-header .search-button').on("click", function(){
		if(jQuery(this).hasClass('active')) {
			jQuery(this).removeClass('active');
			jQuery('.search-popup').fadeOut();
		} else {
			jQuery(this).addClass('active');
			jQuery('.search-popup').fadeIn();
		}
	});

	jQuery('.search-popup .close').on("click", function(){
		jQuery('.site-header .search-button').removeClass('active');
		jQuery('.search-popup').fadeOut();
	});

    /*------------------------------------------------------------------
	[ Banner Categories ]
	*/

	jQuery('.category-button').on('click', function() {
		if(jQuery(this).hasClass('active')) {
			jQuery(this).parents('.banner-area').find('.category-button').removeClass('active');
			jQuery(this).parents('.banner-area').find('.banner-categories').removeClass('active');
		} else {
			jQuery(this).parents('.banner-area').find('.category-button').addClass('active');
			jQuery(this).parents('.banner-area').find('.banner-categories').addClass('active');
		}
	});

	jQuery(document).mouseup(function (e){
		var div = jQuery('.banner-categories, .category-button');
		if (!div.is(e.target) && div.has(e.target).length === 0) {
			div.removeClass('active').parents('.banner-area').find('.category-button').removeClass('active');
		}
	});
	
	/*------------------------------------------------------------------
	[ Split Screen ]
	*/

	jQuery('.split-screen').each(function() {
		var container = jQuery(this),
			item = container.find('.item'),
			index = 0;

		if(item.length > 1) {
			container.append('<div class="nav"></div>');
			item.each(function() {
				container.find('.nav').append('<div class="nav-item"><span>'+leadZero(parseInt(jQuery(this).index()+1))+'</span></div>');
			});
		}

		if(item.find('.slide').length > 1) {
			item.find('.right-side').addClass('owl-carousel').owlCarousel({
				loop:true,
				items:1,
				nav: false,
				dots: true,
				autoplay: false,
				autoplayHoverPause: true,
				navText: false,
			});
		}

		item.eq(0).addClass('active');
		container.find('.nav-item').eq(0).addClass('active');

		container.find('.nav-item').on('click', function() {
			if(!jQuery(this).hasClass('active')) {
				jQuery(this).addClass('active').siblings().removeClass('active');
				item.eq(jQuery(this).index()).addClass('active').siblings().removeClass('active');
			}
		});

		container.on('mousewheel', function (e) {
	        if (e.originalEvent.deltaY>0) {
	        	if(index == 0) {
		        	index = item.length-1;
		        } else {
		            index --;
		        }
	        } else {
	            if(index == item.length-1) {
		        	index = 0;
		        } else {
		            index ++;
		        }
	        }
	        jQuery('.nav-item').eq(index).addClass('active').siblings().removeClass('active');
			item.eq(index).addClass('active').siblings().removeClass('active');
	        e.preventDefault();
	    });
	});
	
	/*------------------------------------------------------------------
	[ Navigation ]
	*/

	jQuery('.nav-button.hidden_menu, .nav-button.visible_menu').on('click', function() {
		if(jQuery(this).hasClass('active')) {
			jQuery(this).removeClass('active');
			jQuery('.navigation').removeClass('active');
			jQuery('body').removeClass('navigation-opened');
		} else {
			jQuery(this).addClass('active');
			jQuery('.navigation').addClass('active');
			jQuery('body').addClass('navigation-opened');
		}
	});

	jQuery('.nav-button.minified-button').on('click', function() {
		if(jQuery(this).hasClass('active')) {
			jQuery(this).removeClass('active').find('.butter-button').removeClass('active');
			jQuery('.minified-block, .navigation, .nav-button.hidden_menu').removeClass('active');
			jQuery('body').removeClass('navigation-opened');
		} else {
			jQuery(this).addClass('active').find('.butter-button').addClass('active');
			jQuery('.minified-block, .navigation, .nav-button.hidden_menu').addClass('active');
			jQuery('body').addClass('navigation-opened');
		}
	});

	jQuery('.nav-button.full_screen').on('click', function() {
		if(jQuery(this).hasClass('active')) {
			jQuery(this).removeClass('active');
			jQuery('.full-screen-nav').fadeOut();
		} else {
			jQuery(this).addClass('active');
			jQuery('.full-screen-nav').fadeIn();
		}
	});

	jQuery('.full-screen-nav .close').on("click", function(){
		jQuery('.nav-button.full_screen').removeClass('active');
		jQuery('.full-screen-nav').fadeOut();
	});

	jQuery('.full-screen-nav .menu-item-has-children > a').on("click", function(){
		if(!jQuery(this).hasClass('active')) {
			jQuery(this).addClass('active').parent().children('.sub-menu').slideDown().parent().siblings().children('a').removeClass('active').next('.sub-menu').slideUp();
			return false;
		}
	});

	jQuery('.side-navigation ul li.menu-item-has-children > a,.side-navigation ul li.page_item_has_children > a').on('click', function(){
		jQuery(this).parents('li').addClass('active-child');
		return false;
	});

	jQuery('.side-navigation .sub-menu .back,.side-navigation .children .back').on('click', function(){
		jQuery(this).parent().parent().removeClass('active-child');
		return false;
	});
	
	/*------------------------------------------------------------------
	[ Banner Categories Button ]
	*/

	jQuery('.banner-categories-button').on('click', function() {
		if(jQuery(this).hasClass('active')) {
			jQuery(this).removeClass('active').parent().find('.banner-categories-carousel').removeClass('active');
		} else {
			jQuery(this).addClass('active').parent().find('.banner-categories-carousel').addClass('active');
		}
	});
	
	/*------------------------------------------------------------------
	[ Side bar ]
	*/

	jQuery('.sidebar-button').on('click', function() {
		if(jQuery(this).hasClass('active')) {
			jQuery(this).removeClass('active');
			jQuery('.side-bar-area').removeClass('active');
		} else {
			jQuery(this).addClass('active');
			jQuery('.side-bar-area').addClass('active');
		}
	});

	jQuery('.side-bar-area .close').on("click", function(){
		jQuery('.side-bar-area, .sidebar-button').removeClass('active');
	});

	jQuery('input, textarea').on('focusin', function() {
		jQuery(this).addClass('focus');
	}).on('focusout', function() {
		if(!jQuery(this).val()) {
			jQuery(this).removeClass('focus');
		}
	});

	/*------------------------------------------------------------------
	[ Fixed header ]
	*/

	jQuery(window).on("load resize scroll", function(){
		if ( jQuery(document).scrollTop() > 0 ) {
			jQuery('.site-header').addClass('fixed');
		} else {
			jQuery('.site-header').removeClass('fixed');
		}


		jQuery('body.home.base-theme').each(function() {
			if ( jQuery(document).scrollTop() > jQuery(window).height()*0.5 ) {
				jQuery('.site-header').addClass('show');
			} else {
				jQuery('.site-header').removeClass('show');
			}
		});
	});

	/*------------------------------------------------------------------
	[ Screen rezise events ]
	*/
	
	var nav_el = '';
	if(jQuery('.navigation').hasClass('visible_menu')) {
		nav_el = 'yes';
	}
	jQuery(window).on("load resize", function(){
		jQuery('.banner-area').each(function() {
			if((jQuery(this).offset().top-jQuery('#wpadminbar').outerHeight()) == 0) {
				jQuery(this).addClass('on-top').find('.container > .cell').css('padding-top', parseInt(30+jQuery('#wpadminbar').outerHeight()+jQuery('.site-header').outerHeight()))
			}
		});

		/*------------------------------------------------------------------
		[ Mobile menu ]
		*/
		if(jQuery(window).width() <= '769') {
			jQuery('.navigation .menu-item-has-children > a').on("click", function(){
				if(!jQuery(this).hasClass('active')) {
					jQuery(this).addClass('active').parent().children('.sub-menu').slideDown().siblings().children('.sub-menu').slideUp();
					return false;
				}
			});
		}


	    jQuery('.header-space').css('height', jQuery('.site-header').outerHeight()+jQuery('.header + .navigation').outerHeight()+jQuery('.ypromo-site-bar').outerHeight());

	    jQuery('main.main-row').css('min-height', jQuery(window).outerHeight()-jQuery('.site-footer').outerHeight()-jQuery('.header-space:not(.hide)').outerHeight()-jQuery('.ypromo-site-bar').outerHeight()-jQuery('#wpadminbar').outerHeight());

		jQuery('.banner:not(.fixed-height)').each(function(){
			var coef = 0;
			jQuery(this).css('height', jQuery(window).outerHeight()-jQuery('.header-space:not(.hide):visible').outerHeight()-jQuery('#wpadminbar').outerHeight()-coef);
			jQuery(this).find('.item, .cell').css('height', jQuery(this).height());
		});
		jQuery('.banner.fixed-height').each(function(){
			jQuery(this).find('.item, .cell').css('height', jQuery(this).height());
		});

		jQuery('.full-screen-nav .cell').css('height', jQuery(window).height()-20-jQuery('#wpadminbar').height());

		if (nav_el == "yes") {
			if(jQuery(window).width() >= 769) {
				jQuery('.navigation').addClass('visible_menu');
				jQuery('.nav-button').addClass('hidden');
			} else {
				jQuery('.navigation').removeClass('visible_menu');
				jQuery('.nav-button').removeClass('hidden').removeClass('active');
			}
		}

		jQuery('.banner-categories-carousel').each(function() {
			var area = jQuery(this).parent('.banner-area').height();
			jQuery(this).find('.item').css('height', area);
		});

		jQuery('div[data-vc-full-width-mod="true"]').each(function() {
			var coef = (jQuery('.container').outerWidth()-jQuery('#all').width())/2;
			jQuery(this).css('left', coef).css('width', jQuery('#all').width());
		});

		jQuery('.blog-type-grid').each(function(){
			equalHeight(jQuery(this).find('.blog-item .content'));
		});

		jQuery('.benefit-items').each(function(){
			equalHeight(jQuery(this).find('.item'));
		});

		jQuery('.team-items').each(function(){
			equalHeight(jQuery(this).find('.team-item'));
		});

		jQuery('.products').each(function(){
			equalHeight(jQuery(this).find('.woocommerce-LoopProduct-link'));
			equalHeight(jQuery(this).find('.product'));
		});

		jQuery('.icon-box-items').each(function(){
			equalHeight(jQuery(this).find('.icon-box-item'));
			equalHeight(jQuery(this).find('.icon-box-item-style2'));
		});

		jQuery('.num-box-items').each(function(){
			equalHeight(jQuery(this).find('.item'));
		});

		jQuery('.benefits').each(function(){
			equalHeight(jQuery(this).find('.benefit-item'));
		});

		jQuery('div.category').each(function(){
			equalHeight(jQuery(this).find('.category-item'));
			equalHeight(jQuery(this).find('.wrap'));
		});

		jQuery('.split-screen').each(function() {
			var container = jQuery(this);
			container.css('height', jQuery(window).outerHeight()-jQuery('.header-space:not(.hide)').height()-jQuery('#wpadminbar').outerHeight());
			container.find('.item, .cell, .slide').css('height', container.height());
		});

		jQuery('.side-header .wrap').each(function() {
			var height = jQuery(this).height();
			jQuery(this).find('.cell').css('height', height);
		});

		jQuery('.project-horizontal .cell').css('height', jQuery('.project-horizontal').outerHeight());

		jQuery('.ph-slider .item img, .ph-slider, .portfolio-h .cell').css('height', jQuery(window).outerHeight()-jQuery('.header-space:not(.hide)').height()-jQuery('.site-footer').outerHeight()-jQuery('.minified-footer').outerHeight()-jQuery('#wpadminbar').outerHeight());

		jQuery('.projects-slider').css('height', jQuery(window).outerHeight()-jQuery('.site-footer').outerHeight()-jQuery('.site-header').outerHeight()-jQuery('.ypromo-site-bar').outerHeight()-jQuery('#wpadminbar').outerHeight());

		jQuery('.portfolio-h').each(function(){
			var parent_w = jQuery(this).width();

			jQuery(this).find('.ph-slider-area').css('margin-right', -(jQuery(window).width()-parent_w)/2);
		});

		jQuery('.about-us-img-on-bottom').each(function(){
			var offset_top = parseInt(jQuery(this).offset().top),
				w_height = parseInt(jQuery(window).outerHeight()-jQuery('.header-space:not(.hide)').height());

			jQuery(this).css('padding-top', parseInt(w_height-offset_top-jQuery(this).height()));
		});
		
		jQuery('.sb-block > .cell').css('height', jQuery(window).outerHeight()-jQuery('.header-space:not(.hide)').height()-jQuery('#wpadminbar').outerHeight());
		
		jQuery('.project-type1').css('min-height', jQuery(window).outerHeight()-jQuery('.header-space:not(.hide)').height()-jQuery('#wpadminbar').outerHeight());

		/*------------------------------------------------------------------
		[ Fix centered container ]
		*/
		jQuery('.centered-container').each(function() {
			var width = parseInt(Math.round(jQuery(this).width()).toFixed(0)),
				height = parseInt(Math.round(jQuery(this).height()).toFixed(0));

			jQuery(this).css('width', '').css('height', '');

			if ( width & 1 ) {jQuery(this).css('width', (width+1)+'px');}

			if ( height & 1 ) {jQuery(this).css('height', (height+1)+'px');}
		});

		/*------------------------------------------------------------------
		[ Parallax ]
		*/
		jQuery('.background-parallax').each(function(){
			var wScroll = jQuery(window).scrollTop()-jQuery(this).parent().offset().top+jQuery('#wpadminbar').height()+jQuery('.header-space').height();
	 		jQuery(this).css('transform', 'translate(0px,' + wScroll + 'px)');
	 		jQuery(this).parents('.owl-carousel').find('.owl-nav div').css('margin-top', wScroll);
		});

		jQuery('.brand-logo-items').each(function() {
			var el = jQuery(this).find('.brand-logo-item'),
				length = el.length,
				width = jQuery(this).width();

			el.css('width', width/length);
		});
	});

	setTimeout(function() {jQuery(window).trigger('resize').trigger('scroll');},500);

	/*------------------------------------------------------------------
	[ Accordion ]
	*/

	jQuery('.accordion-items .item .top').on('click', function() {
		if(jQuery(this).parent().hasClass('active')) {
			jQuery(this).parent().removeClass('active').find('.wrap').slideUp();
		} else {
			jQuery(this).parent().addClass('active').find('.wrap').slideDown();
		}
	});

	/*------------------------------------------------------------------
	[ Project horizontal slider ]
	*/
	jQuery('.project-horizontal-slider').each(function(){
		var head_slider = jQuery(this);
		if(head_slider.find('.item').length > 1){
			head_slider.imagesLoaded( function() {
				head_slider.addClass('owl-carousel').owlCarousel({
					items:1,
					nav: true,
					dots: false,
					autoplay: false,
					autoWidth: true,
					navClass: ['owl-prev base-icons-prev','owl-next base-icons-next'],
					navText: false,
					margin: 30,
					responsive:{
						0:{
							nav: false,
						},
						480:{

						},
						769:{
							nav: true,
						},
					}
				});
			});
			head_slider.on('mousewheel', '.owl-stage', function (e) {
			    if (e.originalEvent.deltaY>0) {
			        head_slider.trigger('next.owl');
			    } else {
			        head_slider.trigger('prev.owl');
			    }
			    e.preventDefault();
			});
		}
	});


    /*------------------------------------------------------------------
	[ Scroll top button ]
	*/

	jQuery('#scroll-top').on("click", function(){
		jQuery('body, html').animate({ scrollTop: '0' }, 1100); 
		return false;
	});

	jQuery(window).on("load", function(){
		/*------------------------------------------------------------------
		[ Portfolio items & filtering ]
		*/
		jQuery('.portfolio-items:not(.disable-iso)').each(function(){
			var $grid = jQuery(this).isotope({
				itemSelector: 'article',
				horizontalOrder: true
			});

			jQuery(this).prev('.filter-button-group').on( 'click', 'button', function() {
				jQuery(this).addClass('active').siblings().removeClass('active');
				var filterValue = jQuery(this).attr('data-filter');
				$grid.isotope({ filter: filterValue });
				jQuery(window).trigger('resize').trigger('scroll');
			});
		});
		jQuery('.post-gallery-masonry').each(function(){
			var $grid = jQuery(this).isotope({
				itemSelector: 'div',
				horizontalOrder: true
			});
		});

		/*------------------------------------------------------------------
		[ Blog items & filtering ]
		*/
		jQuery('.blog-items:not(.disable-iso)').each(function(){
			var $grid = jQuery(this).isotope({
				itemSelector: 'article'
			});

			jQuery(this).prev('.filter-button-group').on( 'click', 'button', function() {
				jQuery(this).addClass('active').siblings().removeClass('active');
				var filterValue = jQuery(this).attr('data-filter');
				$grid.isotope({ filter: filterValue });
				jQuery(window).trigger('resize').trigger('scroll');
			});
		});
	});

	/*------------------------------------------------------------------
	[ Comment reply ]
	*/

	jQuery('.replytocom').on('click', function(){
		var id_parent = jQuery(this).attr('data-id');
		jQuery('#comment_parent').val(id_parent);
		jQuery('#respond').appendTo(jQuery(this).parents('.comment-item'));
		jQuery('#cancel-comment-reply-link').show();
		return false;
	});

	jQuery('#cancel-comment-reply-link').on('click', function(){
		jQuery('#comment_parent').val('0');
		jQuery('#respond').appendTo(jQuery('#commentform-area'));
		jQuery('#cancel-comment-reply-link').hide();
		return false;
	});

	/*------------------------------------------------------------------
	[ Quantity ]
	*/

	jQuery('.quantity .down').on("click", function(){
		var val = jQuery(this).parent().find('.input-text').val();
		if(val > 1) {
			val = parseInt(val) - 1;
			jQuery(this).parent().find('.input-text').val(val);
		}
		return false;
	});

	jQuery('.quantity .up').on("click", function(){
		var val = jQuery(this).parent().find('.input-text').val();
		val = parseInt(val) + 1;
		jQuery(this).parent().find('.input-text').val(val);
		return false;
	});

	/*------------------------------------------------------------------
	[ Animations ]
	*/

	jQuery(window).on('load scroll', function(){
		jQuery('.skill-item .chart').each(function(){
			var top = jQuery(document).scrollTop()+jQuery(window).height();
			var pos_top = jQuery(this).offset().top;
			if (top > pos_top) {
				jQuery(this).addClass('animated');
			}
		});
		
		jQuery(".wpb_animate_when_almost_visible:not(.wpb_start_animation)").each(function(){
			var th = jQuery(this);
			th.imagesLoaded( function() {
				var top = jQuery(document).scrollTop()+jQuery(window).height(),
					pos_top = th.offset().top;
				if (top > pos_top) {
					th.addClass('wpb_start_animation animated');
				}
			});
		});
		
		jQuery('.skill-item .rating-line').each(function(){
			var top = jQuery(document).scrollTop()+jQuery(window).height(),
				pos_top = jQuery(this).offset().top,
				val = jQuery(this).data('percent');
			if (top > pos_top) {
				if(!jQuery(this).hasClass('animated')) {
					jQuery(this).addClass('animated').find('.line').css('width', val+'%');
				}
			}
		});

		jQuery('.page-grid-lines').each(function() {
			var scroll_top = jQuery(window).scrollTop(),
				css = '';
			if(jQuery('.page-grid-lines-style').length == 0) {
				jQuery('head').append('<style class="page-grid-lines-style"></style>');
			}

			css = '.page-grid-lines div:nth-child(1):after { background-position: 0 '+parseInt(scroll_top*0.3)+'px; }';
			css += '.page-grid-lines div:nth-child(2):after { background-position: 0 '+parseInt(scroll_top*-0.3)+'px; }';
			css += '.page-grid-lines div:nth-child(3):after { background-position: 0 '+parseInt(scroll_top*0.4)+'px; }';

			jQuery('.page-grid-lines-style').html(css);
		});
	});

	jQuery(window).scroll(num_scr);

	function num_scr() {
		jQuery('.num-box-items.style1 .item .num').each(function() {
			var top = jQuery(document).scrollTop()+jQuery(window).height();
			var pos_top = jQuery(this).offset().top;
			if (top > pos_top) {
				jQuery(window).off("scroll", num_scr);
				if(!jQuery(this).hasClass('animated')) {
					jQuery(this).addClass('animated').prop('Counter',0).animate({
						Counter: jQuery(this).text()
					}, {
						duration: 3000,
						easing: 'swing',
						step: function (now) {
							jQuery(this).text(Math.ceil(now));
						}
					});
				}
			}
		});
	}


	if(jQuery('.popup-gallery').length > 0) {
		jQuery('body').append('<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true"> <div class="pswp__bg"></div><div class="pswp__scroll-wrap"> <div class="pswp__container"> <div class="pswp__item"></div><div class="pswp__item"></div><div class="pswp__item"></div></div><div class="pswp__ui pswp__ui--hidden"> <div class="pswp__top-bar"> <div class="pswp__counter"></div><button class="pswp__button pswp__button--close" title="Close (Esc)"></button> <button class="pswp__button pswp__button--share" title="Share"></button> <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button> <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button> <div class="pswp__preloader"> <div class="pswp__preloader__icn"> <div class="pswp__preloader__cut"> <div class="pswp__preloader__donut"></div></div></div></div></div><div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap"> <div class="pswp__share-tooltip"></div></div><button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"> </button> <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"> </button> <div class="pswp__caption"> <div class="pswp__caption__center"></div></div></div></div></div>')

		var $pswp = jQuery('.pswp')[0];
	    var image = [];

	    jQuery('.popup-gallery').each( function() {
	        var $pic     = jQuery(this);
	        $pic.on('click', '.popup-item, article', function(event) {
	       		var getItems = function() {
	                var items = [],
	                	$el = '';
	                if($pic.hasClass('owl-carousel')) {
	                	$el = $pic.find('.owl-item:not(.cloned) a:visible');
	                } else {
	                	$el = $pic.find('a');
	                }
	                $el.each(function() {
	                    var $href   = jQuery(this).attr('href'),
	                        $size   = jQuery(this).data('size').split('x'),
	                        $width  = $size[0],
	                        $height = $size[1];

	                    if(jQuery(this).data('type') == 'video') {
	                    	var item = {
	                    		html: jQuery(this).data('video')
	                    	};
	                    } else {
		                    var item = {
		                        src : $href,
		                        w   : $width,
		                        h   : $height
		                    }
		                }

	                    items.push(item);
	                });
	                return items;
	            }

		        var items = getItems();

		        jQuery.each(items, function(index, value) {
		            image[index]     = new Image();
		            if(value['src']) {
		            	image[index].src = value['src'];
		            }
		        });

	            event.preventDefault();
	            
	            var $index = jQuery(this).index();
	            if(jQuery(this).parent().hasClass('thumbnails')) {
	            	$index++;
	            }
	            if(jQuery(this).parent().hasClass('owl-item')) {
	            	$index = jQuery(this).data('id');
	            }
	            var options = {
	                index: $index,
	                bgOpacity: 0.7,
	                showHideOpacity: true
	            }

	            var lightBox = new PhotoSwipe($pswp, PhotoSwipeUI_Default, items, options);
	            lightBox.init();

	            lightBox.listen('beforeChange', function() {
	            	var currItem = jQuery(lightBox.currItem.container);
	            	jQuery('.pswp__video').removeClass('active');
	            	var currItemIframe = currItem.find('.pswp__video').addClass('active');
	            	jQuery('.pswp__video').each(function() {
	            		if (!jQuery(this).hasClass('active')) {
	            			jQuery(this).attr('src', jQuery(this).attr('src'));
	            		}
	            	});
	            });

	            lightBox.listen('close', function() {
	            	jQuery('.pswp__video').each(function() {
	            		jQuery(this).attr('src', jQuery(this).attr('src'));
	            	});
	            });
	        });
	    });
	}
});

